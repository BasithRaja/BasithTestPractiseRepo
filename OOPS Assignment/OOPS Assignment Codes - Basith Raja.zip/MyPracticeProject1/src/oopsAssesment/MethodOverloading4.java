//4. Method Overloading
//
//Create a class Calculator with overloaded methods add():
//
//add(int a, int b)
//
//add(double a, double b)
//Call both methods inside the main method and print results.


package oopsAssesment;


class Calculator {
	
	int add (int a,int b) {
		int c = a+b;
		return(c);
	}
	double add (double a,double b) {
		double d = a+b;
		return(d);
	}
	
}
public class MethodOverloading4 {

	public static void main(String[] args) {
		
		Calculator obj =  new Calculator();
		System.out.println(obj.add(123,321));
		System.out.println(obj.add(90000.0, 150000.0));
		

	}

}
