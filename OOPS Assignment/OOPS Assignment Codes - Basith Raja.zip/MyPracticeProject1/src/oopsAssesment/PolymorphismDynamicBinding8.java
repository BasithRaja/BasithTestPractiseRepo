//8.  Polymorphism (Dynamic Binding)
//
//Create a parent class Shape with a method area().
//Create subclasses Rectangle and Circle and override the area() method.
//Create a reference of Shape and assign objects of both subclasses one by one, calling area() each time.


package oopsAssesment;

class Shape{
	
	void area() {
		System.out.println("Shape class");
	}
	
}

class Rectangle extends Shape {
	
	@Override
	void area() {
		System.out.println("Rectangle class");
	}
}

class Circle extends Shape {
	
	@Override
	void area() {
	System.out.println("Circle class"); 
	}
}
	
public class PolymorphismDynamicBinding8 {

	public static void main(String[] args) {
		Shape ref;
		
		ref = new Rectangle();
		ref.area();
		ref = new Circle();
		ref.area();

	}

}
