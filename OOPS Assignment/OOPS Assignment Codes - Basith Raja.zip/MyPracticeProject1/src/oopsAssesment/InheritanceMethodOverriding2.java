//2.  Inheritance + Method Overriding
//
//Create a base class Vehicle with a method fuelType() which prints "Runs on fuel".
//Create a child class ElectricCar and override the fuelType() method to print "Runs on electricity".
//Create objects of both classes and call their respective methods.


package oopsAssesment;

class Vehicle {
	
	void fuelType() {
		
		System.out.println("Runs on fuel");
	}
}

class ElectricCar extends Vehicle {
	
	@Override
	void fuelType() {
		
		System.out.println("Runs on electricity");
	}
	
}

public class InheritanceMethodOverriding2 {

	public static void main(String[] args) {
		
		Vehicle obj = new Vehicle();
		ElectricCar obj1 = new ElectricCar();
		obj.fuelType();
		obj1.fuelType();

	}

}
