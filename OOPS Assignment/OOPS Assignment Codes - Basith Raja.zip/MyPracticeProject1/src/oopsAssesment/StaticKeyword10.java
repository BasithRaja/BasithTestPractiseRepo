//10.  Static Keyword
//
//Create a class Student having static variable collegeName and instance variables name and rollNo.
//Write a method to print both static and instance data.
//Create multiple objects to show static value remains constant.


package oopsAssesment;


class Student1 {
	
	static String collegeName =  "Maxwell";
	String name;
	int rollNo;
	
	Student1(String n, int r){
		
		name = n;
		rollNo = r;
		
	}
	
	void printMethod() {
	
		System.out.println(name+" "+rollNo+" "+collegeName);
	
	}
}

public class StaticKeyword10 {

	public static void main(String[] args) {
		Student1 obj=new Student1("Basith",777);
		obj.printMethod();
		Student1 obj1=new Student1("Raja",778);
		obj1.printMethod();
		Student1 obj2=new Student1("Ajith",779);
		obj2.printMethod();
		

	}

}
