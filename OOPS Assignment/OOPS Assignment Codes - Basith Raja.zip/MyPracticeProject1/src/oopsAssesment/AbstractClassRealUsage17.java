//17.  Abstract Class + Real Usage
//
//Create an abstract class Employee with:
//
//abstract method: calculateSalary()
//
//concrete method: employeeDetails()
//Subclass FullTimeEmployee and PartTimeEmployee implementing salary calculation logic differently.



package oopsAssesment;

abstract class Employee1 {
	
void employeeDetails() {
		
	System.out.println("Parttime Employee Name: Ajith");
	System.out.println("Fulltime Employee Name: Basith Raja");
	System.out.println();
		
	}
abstract double calculateSalary(int a, double b);
	
	}
	
	
class ParttimeEmployee extends Employee1 {

	double calculateSalary(int totalworkinghoursperday, double salaryPerHour) {
		return(totalworkinghoursperday*salaryPerHour);
		
	}
	
}

class FulltimeEmployee extends Employee1 {
	
	double calculateSalary(int totalworkingdayspermonth, double salaryPerDay) {
		return(totalworkingdayspermonth*salaryPerDay);
		
	}
	

}

public class AbstractClassRealUsage17 {

	public static void main(String[] args) {
		
		
		Employee1 ref = new ParttimeEmployee();
		Employee1 ref1 = new FulltimeEmployee();
		
		ref.employeeDetails();
		System.out.println("Ajith Salary is: "+ ref.calculateSalary(4,200)+"  "+ "Per Day");
		System.out.println("Basith Raja Salary is: "+ ref1.calculateSalary(30,1600)+"  "+"Per Month");
	
		
		
		
	}

}
