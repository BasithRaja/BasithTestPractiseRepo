//26>    WAP in Java to create a class named school 
//create name, address,strength as their instance variables 
//Create two constructor one with two variables and one with all the three variables 
//Create a method that will display all the three parameters 
//create two object of this class and call the respective methods 


package oopsAssesment;

class School1 {
	
	String name;
	String address;
	String strength;
	
	School1(String name,String address){
	this.name=name;
	this.address=address;
	}		
	
	School1(String name,String address, String strength){
		this(name, address);
		this.strength=strength;
	}
		
	void display() {
		System.out.println(name+"    "+address+"     "+strength);
	}
}

public class WAPinJava26 {

	public static void main(String[] args) {
		
       School1 obj = new School1("Maxwell","No.20/AP Road-Bangalore");
       School1 obj1 = new School1("Maxwell","No.20/AP Road-Bangalore","Teaching Quality & Affordable fee structure");
	   obj.display();
	   obj1.display();
	}

}
