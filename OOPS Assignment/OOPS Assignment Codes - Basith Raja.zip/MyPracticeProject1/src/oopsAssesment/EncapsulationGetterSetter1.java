

//1.Encapsulation + Getter/Setter
//
//WAP in Java
//Create a class named Employee with private instance variables empId, empName, and salary.
//Provide public getters and setters for all variables.
//Create a method displayDetails() to print employee details.
//Create an object in the main method and assign values using setters then display them.


package oopsAssesment;

class Employee {
	
	private int empID;
	private String empName;
	private float salary;
	public int getEmpID() {
		return empID;
	}
	public void setEmpID(int empID) {
		this.empID = empID;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	
	void displayDetails() {
		
		System.out.println("Employee ID: "+ empID);
		System.out.println("Employee Name: "+ empName);
		System.out.println("Employee Salary: "+ salary);
		
	}
	
}

public class EncapsulationGetterSetter1 {

	public static void main(String[] args) {
		
		Employee obj = new Employee();
		obj.setEmpID(1234);
		obj.setEmpName("Basith Raja");
		obj.setSalary(90000);
		obj.displayDetails();

	}

}
