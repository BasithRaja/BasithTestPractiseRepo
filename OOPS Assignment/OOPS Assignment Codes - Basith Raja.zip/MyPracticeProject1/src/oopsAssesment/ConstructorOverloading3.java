//Constructor Overloading
//
//Create a class Product having instance variables productId, productName, and price.
//Implement:
//
//A default constructor that prints "Product Created".
//
//A parameterized constructor that initializes the product details.
//Write a method displayProduct() to print product details.
//Create both types of objects in the main method.



package oopsAssesment;


class Product {
	
	int productID;
	String productName;
	double productPrice;
	
	Product()  {
		
		System.out.println("Product Created");
	}
	
	Product(int i, String n, double p) {
		productID=i;
		productName=n;
		productPrice=p;		
		
	}
	
	void displayProduct() {
		
		System.out.println("Product ID: "+ productID);
		System.out.println("Product Name: "+ productName);
		System.out.println("Product Price: "+ productPrice);
	}
}
	

public class ConstructorOverloading3 {

	public static void main(String[] args) {
		
		Product obj = new Product();
		Product obj1 = new Product(1234,"Mobile",150000);
		obj1.displayProduct();
		

	}

}
