//21.  Static Concepts
//
//Create a class University with:
//
//static variable country = "India"
//
//instance variable universityName
//Print values using different objects to show static effect.



package oopsAssesment;

class University {
	
	static String country = "India";
	String universityName;
	
 University(String U) {
	 
	 universityName=U;
 }
	
	void toPrint() {
		System.out.println(universityName+", "+"Location: "+ country);
	}
	
}
public class StaticConcepts21 {

	public static void main(String[] args) {
		
		University obj = new University("Anna University");
		obj.toPrint();
		University obj1 = new University("SRM University");
		obj1.toPrint();
		University obj2 = new University("IIT University");
		obj2.toPrint();
		University obj3 = new University("kamaraj University");
		obj3.toPrint();
		University obj4 = new University("Islamic University");
		obj4.toPrint();
	}

}
