//19. Polymorphism (Runtime + Upcasting)
//
//Create a class Camera with a method capture().
//Create a subclass DSLCamera that overrides the method.
//Use parent reference to call child object method (dynamic polymorphism).



package oopsAssesment;


class Camera {
	
	void capture() {
		System.out.println("Camera capture images");
	}
}

class DSLCamera extends Camera{
	
	@Override
	void capture() {
		System.out.println("DSLCamera capture images in better quality");
	}
	
}
public class PolymorphismRuntimeandUpcasting19 {

	public static void main(String[] args) {
		
		Camera ref = new DSLCamera();
		ref.capture();
	
		
	}

}
