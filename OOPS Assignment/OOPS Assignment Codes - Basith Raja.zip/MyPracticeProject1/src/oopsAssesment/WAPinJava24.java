//24 >   WAP in Java 
//Create a Class named Shape with length as instance variable  , create three methods as square , rectangle , circle 
//and find out their respective areas 
//Create a object in main method and call these different methods with the instance of object 



package oopsAssesment;

class Shape1{
	
	
	int square(int s) {
		return s*s;
	}
	
	int rectangle (int length, int breath) {
		return length*breath;
	}
	
	double circle(double pi, int r) {
		return pi*(r*r);
	}
}

public class WAPinJava24 {

	public static void main(String[] args) {
		
		Shape1 obj = new Shape1();
		System.out.println("Area of Square: "+obj.square(4)+" "+ "sq.units");
		System.out.println("Area of Rectangle: "+obj.rectangle(20,10)+" "+ "sq.units");
		System.out.println("Area of Circle: "+obj.circle(3.14, 10)+" "+ "sq.units");

	}

}
