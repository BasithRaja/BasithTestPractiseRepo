//9.  Final Keyword
//
//Create a class Bank with a final variable IFSC and final method showIFSC().
//Try creating a subclass HDFCBank and attempt overriding the final method (should show compile-time restriction).
//Create a main method to demonstrate usage.



package oopsAssesment;

class Bank {
	
	final String a = "IFSC";
	final void showIFSC() {
		System.out.println(a);
	}
}

class HDFCBANK extends Bank {
	
	@Override
	void showIFSC() {
		System.out.println("Trying Override");
	}
}
public class FinalKeyword9 {

	public static void main(String[] args) {
		Bank ref;
		
		ref = new HDFCBANK();
		ref.showIFSC();

	}

}
