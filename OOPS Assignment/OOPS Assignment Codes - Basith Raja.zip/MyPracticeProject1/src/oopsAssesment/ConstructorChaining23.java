//23.  Constructor Chaining
//
//Create a class Mall with:
//
//Default constructor printing "Welcome to the Mall"
//
//Parameterized constructor calling default constructor using this()
//Demonstrate constructor chaining in main.



package oopsAssesment;

class Mall {

	
	Mall() {
		System.out.println("Welcome to the Mall");
	}
	
	Mall(String a ){
		
	this();
	System.out.println("Constructors Chained");
	}
	
}

public class ConstructorChaining23 {

	public static void main(String[] args) {
		Mall obj = new Mall("Basith");

	}

}
