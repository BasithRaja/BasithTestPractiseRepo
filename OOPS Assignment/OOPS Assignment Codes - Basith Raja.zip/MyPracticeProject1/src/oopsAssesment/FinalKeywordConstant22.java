//Create a class GovernmentRules with a final variable MAX_WORKING_HOURS = 8
//Try modifying it inside main and observe compile-time restriction.



package oopsAssesment;

class GovernmentRules {
	
  final int MAX_WORKING_HOURS = 8;
	
GovernmentRules(int m){
	MAX_WORKING_HOURS=m;
}

void method() {
	
	System.out.println(MAX_WORKING_HOURS);
}
	
}

public class FinalKeywordConstant22 {

	public static void main(String[] args) {
	GovernmentRules obj = new GovernmentRules(100);
	obj.method();
		

	}

}
