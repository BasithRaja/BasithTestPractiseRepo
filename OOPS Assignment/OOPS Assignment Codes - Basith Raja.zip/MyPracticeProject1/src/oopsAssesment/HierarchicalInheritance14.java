//14. Hierarchical Inheritance 
//
//Create a class Course with a method courseInfo().
//Create subclasses Science, Commerce, and Arts each with their own method.
//Create objects of each and call methods to show hierarchy.


package oopsAssesment;


class Course {
	
	void courseInfo() {
		System.out.println("Course Subjects are as follows:");
	}
}

class Science extends Course {
	
	void scienceSubjects () {
		System.out.println("Science: Physics,Chemistry,Botany,Zoology");
		System.out.println();
	}
}

class Commerce extends Course {
	
	void CommerceSubjects() {
		System.out.println("Commerce: Statistics,Accounts,Payments,Bankings");
		System.out.println();
	}
}

class Arts extends Course {
	void artsSubject() {
		System.out.println("Arts: English,History,Literature,Computer Science");
		System.out.println();
	}
}

public class HierarchicalInheritance14 {

	public static void main(String[] args) {
		Science obj = new Science();
		obj.courseInfo();
		obj.scienceSubjects();
		Commerce obj1 = new Commerce();
		obj1.courseInfo();
		obj1.CommerceSubjects();
		Arts obj2 = new Arts();
		obj2.courseInfo();
		obj2.artsSubject();
		
	

	}

}
