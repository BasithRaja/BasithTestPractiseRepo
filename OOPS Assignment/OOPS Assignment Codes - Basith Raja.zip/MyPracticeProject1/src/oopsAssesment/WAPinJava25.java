//25>   WAP in Java 
//Create a class named school ,create name as their instance variables 
//Create a default constructor of this class which will have a print statement to display the name of school 
//Create a method inside the class which will display a message as "This School is based out of Kolkata"
//Create a object under main method and call the constructor and the method 


package oopsAssesment;

class School {
	
	String name = "Maxwell";
	
	School(){
		System.out.println("School Name is: "+ name);
	}
	
	void method() {
		System.out.println("This School is based out of Kolkata");
	}
}

public class WAPinJava25 {

	public static void main(String[] args) {
		
		School obj = new School();
		obj.method();
			

	}

}
