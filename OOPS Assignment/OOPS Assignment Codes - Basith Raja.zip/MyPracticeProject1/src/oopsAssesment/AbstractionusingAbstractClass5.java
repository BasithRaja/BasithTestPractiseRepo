//5.  Abstraction using Abstract Class
//
//Create an abstract class Animal with an abstract method sound().
//Create two subclasses Dog and Cat and provide implementation for sound() method.
//Create objects and call sound() for each.


package oopsAssesment;

abstract class Animal{
	
	abstract void sound();
	
}
	
class Dog extends Animal {
	
	void sound() {
		System.out.println("Dog sound: Bark");
	}
	
}	
class Cat extends Animal {
	
	void sound() {
		System.out.println("Cat sound: Meow");
	}
}	
	


public class AbstractionusingAbstractClass5 {

	public static void main(String[] args) {
		
		Dog obj = new Dog();
		Cat obj1 = new Cat();
	    obj.sound();
		obj1.sound();
		
		
		

	}

}
