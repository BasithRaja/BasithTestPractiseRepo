//13. Inheritance (Multilevel)
//
//Create three classes:
//
//Device â†’ method start()
//
//Mobile extends Device â†’ method calling()
//
//SmartPhone extends Mobile â†’ method internet()
//Create object of SmartPhone and call all methods.


package oopsAssesment;


class Device {
	
	void start() {
		System.out.println("Start the Device");
	}
}
class Mobile extends Device {
		void calling() {
			System.out.println("Calling to a friend through mobile");
		}
	} 
	
class SmartPhone extends Mobile {
		void internet() {
			System.out.println("SmartPhones requires Internet to access webportal");
		}
	}


public class InheritanceMultilevel13 {

	public static void main(String[] args) {
		SmartPhone obj = new SmartPhone();
		obj.start();
		obj.calling();
		obj.internet();
		
		

	}

}
