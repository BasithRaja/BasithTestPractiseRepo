//6.  Interface Implementation
//
//Create an interface Payment with a method makePayment().
//Create two classes UPI and CreditCard implementing this interface and define their own payment messages.
//Call the method through interface reference.


package oopsAssesment;

interface Payment{
	
	void makePayment();
	
}

class UPI implements Payment{
	
	public void makePayment() {
		
		System.out.println("Your Money has been successfully transferred through UPI");
		
	}
	
}

class CreditCard implements Payment {
	
	public void makePayment() {
		System.out.println("Your Money has been sucessfully transferred through Credit Card");
	}
}
public class InterfaceImplementation6 {

	public static void main(String[] args) {
		Payment ref = new UPI();
		Payment ref1 = new CreditCard();
		ref.makePayment();
		ref1.makePayment();
		

	}

}
