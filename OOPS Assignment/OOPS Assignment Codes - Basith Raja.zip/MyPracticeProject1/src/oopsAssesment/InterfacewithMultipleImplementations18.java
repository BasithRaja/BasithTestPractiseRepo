//18.  Interface with Multiple Implementations
//
//Create an interface Transport with method booking().
//Implement it in Bus and Flight classes.
//Call using interface reference.




package oopsAssesment;

interface Transport {
	
	void booking();

	
}

class Bus implements Transport {
	
	public void booking() {
		System.out.println("Bus ticket booking is easy and cheaper");
		
	}
	
}

class Flight implements Transport{
	
	public void booking() {
		
		System.out.println("Flight ticket booking is hard and costlier");
		
	}
}

public class InterfacewithMultipleImplementations18 {

	public static void main(String[] args) {
		
		Transport ref; 
		ref = new Bus();
		ref.booking();
		
		ref = new Flight();
		ref.booking();

	}

}
