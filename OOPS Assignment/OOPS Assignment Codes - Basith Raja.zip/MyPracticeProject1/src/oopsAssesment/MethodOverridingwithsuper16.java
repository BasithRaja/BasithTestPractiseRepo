//16.  Method Overriding with super
//
//Create a base class Hospital with a method emergencyService().
//Create a subclass CityHospital that overrides the method and calls parent method using super.emergencyService().
//Demonstrate overriding in main.




package oopsAssesment;


class Hospital {
	
	void emergencyService() {
		System.out.println("Emergency Service will be provided for Critical patients");
	}
}


class CityHospital extends Hospital {
	
		@Override
	void emergencyService() {
		
		System.out.println("Emergency Services will not be provided for Non-Critical patients ");
		super.emergencyService();
		}
		
		
		
}
public class MethodOverridingwithsuper16 {

	public static void main(String[] args) {
		
		CityHospital obj = new CityHospital();
		obj.emergencyService();

	}

}
