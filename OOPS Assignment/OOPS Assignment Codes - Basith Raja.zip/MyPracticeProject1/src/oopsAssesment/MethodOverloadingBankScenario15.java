//15.  Method Overloading (Bank Scenario)
//
//Create a class LoanCalculator with two overloaded methods:
//
//calculateLoan(int amount)
//
//calculateLoan(int amount, double interestRate)
//Print loan details accordingly. Call both methods from main.





package oopsAssesment;


class LoanCalculator{
	
	
	int calculateLoan (int amount) {
		
		return amount;
	}
	
	double calculateLoan (int amount, double interestRate) {
	      return amount + (amount*(interestRate/100));
		  
	}
	
}

public class MethodOverloadingBankScenario15 {

	public static void main(String[] args) {
		LoanCalculator obj = new LoanCalculator();
		System.out.println("Loan Amount: "+obj.calculateLoan(100000));
		System.out.println("Overall Payback Amount(Includes Interest): "+obj.calculateLoan(100000, 9.0));

	}

}
