//5.
//
//Write a program that prints:
//
//"A" if number divisible by 2 and 3
//
//"B" if divisible by 3 and not by 2
//
//"C" if divisible by 2 and not by 3
//
//"D" otherwise



package LoopAssesment;

public class printArBrCrD_Q5 {

	public static void main(String[] args) {
		
		int number = 47;
		
		if (number % 2 == 0 && number % 3 ==0) {
			System.out.println("A");
		} else {
           if (number % 3 == 0  && number % 2 !=0) {
        	System.out.println("B");
           } else {
        		if (number % 2 == 0 && number % 3 !=0) {
					System.out.println("C");
        		} else {
        			System.out.println("D");
				}
        	}
           }
		}

	}


