//23.
//
//Print this pattern using nested for:
//
//1
//12
//123
//1234
//12345
//
//
//But skip printing 3 in all rows




package LoopAssesment;

import java.util.Iterator;

public class NestedForSkipPrinting3_Q23 {

	public static void main(String[] args) {
		
	    for (int i = 1; i <=5; i++) {
	    	
	    	for (int j = 1; j <=i; j++) {
				if (j ==3) {
					continue;
				}
				
				System.out.print(j);
			}
	    	 System.out.println();
		}

	}

}
