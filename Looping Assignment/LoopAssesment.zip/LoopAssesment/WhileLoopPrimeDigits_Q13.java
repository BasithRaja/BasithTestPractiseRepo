//13.
//
//Find the count of prime digits in a number using while loop only



package LoopAssesment;

public class WhileLoopPrimeDigits_Q13 {

	public static void main(String[] args) {
		
		int number = 235468937;
		int count = 0;
		int digit = 0;
		
		while (number>0) {
			digit = number%10;
			number = number/10;
			if (digit==2||digit==3||digit==5||digit==7) {
				count++;			
			}
			
		}
		System.out.println("count of prime digits: "+count);

	}

}
