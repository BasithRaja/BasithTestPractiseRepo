//Write a program that classifies a character as:
//
//Uppercase vowel
//
//Uppercase consonant
//
//Lowercase vowel
//
//Lowercase consonant




package LoopAssesment;

public class CharUppercaseLowerCase_Q9 {

	public static void main(String[] args) {
		 
		char letter = 'p';
		
		if (letter >= 'A' && letter <= 'Z') {
		   if (letter == 'A' || letter == 'E' || letter == 'I' || letter == 'O' || letter == 'U'  ) {
		    System.out.println("The Given Letter is a Uppercase Vowels");
		} else {
            System.out.println("The Given Letter is a Uppercase Consonants");
		}
		} else {
            if (letter >= 'a' && letter <= 'z') {
			   if (letter == 'a' || letter == 'e' || letter == 'i' || letter == 'o' || letter == 'u') {
				System.out.println("The Given Letter is a Lower case Vowels");
			} else {
                System.out.println("The Given Letter is a Lower case Consonants");
			}
			} else {
                System.out.println("The Given Letter is not a Alphabets");
			}
		}
		
		 

	}

}
