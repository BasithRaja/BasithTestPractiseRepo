//8.
//
//Given age and salary:
//
//If age < 25 → Not eligible
//
//If age ≥ 25 and salary < 30000 → Eligible for loan A
//
//If age ≥ 30 and salary ≥ 50000 → Eligible for loan B
//➡️ Use deep nested if



package LoopAssesment;

public class DeepNestedIf_Q8 {

	public static void main(String[] args) {
		 
		int age = 27;
		int salary = 55000;
		
		if (age < 25) {
			  System.out.println("Not Eligible for Loans");
		}
		else {
          if (age>= 30 && salary >= 50000) {
			System.out.println("Eligible for Loan B");
		} else {
           if (age>= 25 && salary < 30000) {
			System.out.println("Eligible for Loan A");
		} else {
			System.out.println("Not Eligible for Loans");
		}
		}
	}

	}
}