//4.
//
//Input an integer and determine whether:
//
//It is positive and divisible by 4
//
//OR negative and divisible by 6



package LoopAssesment;

public class integerdetermineQ4 {

	public static void main(String[] args) {
		
		int number = 0;
		
		if (number>0 && number % 4 == 0) {
			System.out.println(number+" "+"is positive and divisible by 4");
		} else {
           if (number <0 && number % 6 == 0) {
			System.out.println(number+" "+"is negative and divisible by 6");
		}  else {
			System.out.println(number +" "+ "is not satisfy both the conditions");
		}
		}

	}

}
