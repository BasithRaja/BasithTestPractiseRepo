//7.
//
//Write a program to find the largest of four numbers using:
//
//Nested if–else only
//
//No loops
//
//No arrays




package LoopAssesment;

public class NestedIfElseFindLargestNumber_Q7 {

	public static void main(String[] args) {
		
		int A = 10;
		int B = 20;
		int C = 15;
		int D = 15;
		
		if (A==B && B ==C && C==D) {
			System.out.println("All the Numbers are equal");
		} else {
            if (A>=B) {
				if (A>=C) {
					if (A>=D) {
						System.out.println("A is the Largest Number");
					} else {
                        System.out.println("D is the Largest Number");
					}
				} else {
                    if (C>=D) {
						System.out.println("C is the Largest Number");
					} else {
                       System.out.println("D is the Largest Number");
					}
				}
			} else {
                 if (B>=C) {
				    if (B>=D) {
						System.out.println("B is the Largest Number");
					} else {
                        System.out.println("D is the Largest Number");
					}
				} else {
                    if (C>=D) {
						System.out.println("C is the Largest Number");
					} else {
                        System.out.println("D is the Largest Number");
					}
				}
			}
		}
		
	}
	
}