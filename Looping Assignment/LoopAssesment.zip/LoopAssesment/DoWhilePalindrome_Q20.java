//20.
//
//Using do–while, find whether a number is palindrome, but:
//
//Exit loop early if mismatch is found



package LoopAssesment;

public class DoWhilePalindrome_Q20 {

	public static void main(String[] args) {
		
		
		int userInput = 1331;
		int r = userInput;
		int rev = 0;
		int value;
		
		
		do {
            value = userInput%10;
			rev = rev*10+value;
			userInput=userInput/10;
			
		} while (userInput>0);
		
		if (rev == r) {
			System.out.println("Entered Number is Palindrome");
			System.out.println(rev);
			System.out.println(r);
		} else {
			System.out.println("Entered Number is not Palindrome");
		}
	}

}
