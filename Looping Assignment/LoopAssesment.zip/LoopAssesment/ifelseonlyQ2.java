//2.
//
//Given three integers a, b, and c, print the second largest number using:
//
//Only if–else


package LoopAssesment;

public class ifelseonlyQ2 {

	public static void main(String[] args) {
		
		int a = 120, b = 40, c=600;
		int max;
		
		if (a>b) {
			if (a>c) {
				max = a;
			} else {
				max = c;
			}
		} else {
			if (b>c) {
				max = b;
			} else {
				max = c;
			}

		}
		
		
		if (max == a) {
			if (b>c) {
				System.out.println(" b is the second largest");
			} else {
                System.out.println("c is the second largest");
			}
		} else {
			if (max == b) {
				if (a>c) {
					System.out.println("a is the second largest");
				} else {
                    System.out.println("c is the second largest");
				}
			} else {
                if (max == c && a>b) {
					System.out.println("a is the second largest");
				} else {
                    System.out.println("b is the second largest");
				}
			}

		}
		
		
	}

}
