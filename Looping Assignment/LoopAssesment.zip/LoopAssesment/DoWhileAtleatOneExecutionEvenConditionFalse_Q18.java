//18.
//
//Write a program that executes at least once, even if condition is false, and prints:
//
//Loop Executed
//
//
//➡️ Modify condition logically



package LoopAssesment;

public class DoWhileAtleatOneExecutionEvenConditionFalse_Q18 {

	public static void main(String[] args) {
		
		int x =10;
		int max = Integer.MAX_VALUE;

		
		do {
			System.out.println("Loop Executed atleat once even while condition is failed");
			
		} while (x > max);
		

	}

}
