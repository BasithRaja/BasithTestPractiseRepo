//A student is eligible for Physics Honours if:
//
//He/she scores at least 60 in Math, 50 in Physics, and 40 in Chemistry, and
//
//Either the total marks of all three subjects is 180 or more,
//or the sum of Math and Physics marks is 120 or more.
//
//Otherwise, the student is not eligible.


package LoopAssesment;

public class NestedIfElsePhysicsHons_Q6 {

	public static void main(String[] args) {
		
		int Math = 60;
		int Physics = 60;
		int Chemistry = 40;
		int Total = Math+Physics+Chemistry;
		int MathPhysics = Math+Physics;
		
		if (Math>=60) {
			if (Physics >= 50) {
				if (Chemistry >= 40) {
					if (Total >= 180 || MathPhysics >= 120) {
						System.out.println("Student is eligilble for Physics Honours");
					} else {
                        System.out.println("Student is not eligilble for Physics Honours");
					}
				} else {
					System.out.println("Student is not eligilble for Physics Honours");
				}
			} else {
				System.out.println("Student is not eligilble for Physics Honours");
			}
		} else {
			System.out.println("Student is not eligilble for Physics Honours");
		}

	}

}
