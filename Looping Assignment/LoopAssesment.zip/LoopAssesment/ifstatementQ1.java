//1.	Write a Java program that prints "VALID" only if a number:
//
//is divisible by 3
//
//NOT divisible by 5
//
//lies between 50 and 200 (inclusive)
//Otherwise print "INVALID"
//➡️ Use only one if statement


package LoopAssesment;

public class ifstatementQ1 {

	public static void main(String[] args) {
	
		int number = 60;
		
		
		String result = "INVALID NUMBER";
		
		if ((number%3 ==0) && (number%5 !=0) && (number >= 50) && (number <= 200)) {
			
			result = "VALID NUMBER";
		}
		
		System.out.println(result);

	}

}
