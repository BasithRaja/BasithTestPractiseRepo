//10.
//
//Input a number and check:
//
//If it’s a 3-digit number
//
//If yes, check whether the sum of digits is even or odd
//➡️ Use nested if only



package LoopAssesment;

public class NestedIf_threedigitnumber_sumofthreedigit_Q10 {

	public static void main(String[] args) throws InterruptedException {
		
		int a = 100;
		
		
		if (a <= 999 && a >= 100) {
			
             int lastDigit = a%10;  // 0              remember : % 10 → get last digit
             
             int middleDigit1 = a/10;    // 10
             int middleDigit = middleDigit1%10; // 0       remember:     / 10 → remove last digit
             
             int firstDigit1 = middleDigit1/10;       // 1
             int firstDigit = firstDigit1%10;  // 1
             
             int total = lastDigit+middleDigit+firstDigit;
             Thread.sleep(5000);
             if (total % 2 == 0) {
				System.out.println("Sum of a is an Even Number");
			} else {
                System.out.println("Sum of a is an Odd Number");
			}
			
		} else {
            System.out.println("Given Number is not 3 digit");
		}
	}

}
