//🔹 WHILE LOOP (Tricky Iterations)
//11.
//
//Print numbers from 1 to 100 but:
//
//Skip numbers divisible by both 3 and 5
//
//Stop completely when number reaches 77
//➡️ Use while only


package LoopAssesment;

public class WhileLoopPrint1to100_Q11 {

	public static void main(String[] args) {
		
		int i=1;
		
		while (i<=77) {
			
			if (i%3 ==0 && i%5==0) {
				i++;
				continue;
				} else {
						System.out.print(i+ " ");
	                    i++;
					}
                    
				}
			}	
}
			
			
		




