
//14.
//
//Write a program that prints the Fibonacci series up to N terms, but:
//
//Stop printing when a number exceeds 500



package LoopAssesment;

public class FibonacciSeriesWhileLoop_Q14 {

	public static void main(String[] args) {
		
		int n = 100;
		int max = 500;
		int n1=0;
		int n2=1;
		int i=0;
		
        System.out.println("Fibonacci Series number till 500:");
        System.out.print(n1+" "+n2);
        while (i<n) {
			
        	
        	int n3 = n1+n2;
        	if (n3 > max) {
				break;
			}
        	
        	n1=n2;
        	n2=n3;
          System.out.print(" "+n3);
          i++;
		}
	}

}
