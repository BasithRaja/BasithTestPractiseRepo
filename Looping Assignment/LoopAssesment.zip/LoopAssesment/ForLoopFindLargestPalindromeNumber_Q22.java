//22.
//
//Using for, find the largest palindrome number between 100 and 1000



package LoopAssesment;

public class ForLoopFindLargestPalindromeNumber_Q22 {

	 public static void main(String[] args) {

	        int largest = 0;

	        for (int i = 100; i <= 1000; i++) {
	            int num = i;
	            int rev = 0;

	          
	          while (num > 0) {
	                int digit = num % 10;
	                rev = rev * 10 + digit;
	                num = num / 10;
	            }

	          
	            if (rev == i) {
	                largest = i;   
	            }
	        }

	        System.out.println("Largest palindrome between 100 and 1000 is: " + largest);
	    }
	}


