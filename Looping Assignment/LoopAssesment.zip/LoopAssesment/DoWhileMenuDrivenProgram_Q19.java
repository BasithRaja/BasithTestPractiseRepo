//19.
//
//Create a menu-driven program using do–while:
//
//Add
//
//Subtract
//
//Multiply
//
//Exit


package LoopAssesment;

import java.util.Scanner;

public class DoWhileMenuDrivenProgram_Q19 {

	public static void main(String[] args) {
		
		int num1;
		int num2;
		int result;
		char op;
		
		
		Scanner sc = new Scanner(System.in);
		
		do {
			System.out.println("Enter an operator: +,-,*,&");
			op = sc.next().charAt(0);
			
			if (op != '&' && op != '+' && op != '-' && op != '*') {
				System.out.println("Entered Operator is not valid");
				break;
			}
			if (op == '&') {
				System.out.println("System Exited");
				break;
			} else {
				System.out.println("Enter 1st Number: ");
				num1 = sc.nextInt();
				System.out.println("Enter 2nd Number: ");
				num2 = sc.nextInt();
			}
			if (op =='+') {
				result = num1+num2;
				System.out.println("Addition value: "+ result);
			}
			if (op =='-') {
				result = num1-num2;
				System.out.println("Subraction value: "+ result);
			}
			if (op =='*') {
				result = num1*num2;
				System.out.println("Multiply value: "+ result);
			}
			
		} while (op == '+'||op == '-'||op == '*');
		     
         sc.close();
	}

}
