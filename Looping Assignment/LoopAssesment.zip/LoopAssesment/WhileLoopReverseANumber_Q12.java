//Write a program to reverse a number using while, but:
//
//Stop reversing if digit 0 is encountered


package LoopAssesment;

public class WhileLoopReverseANumber_Q12 {

	public static void main(String[] args) {
		
		int num = 10234567;
		int rev = 0;
		
		while (num!=0) {
			
			int thirdVariable = num%10;
			if (thirdVariable==0) {
				break;
			}
			rev=rev*10+thirdVariable;
			num=num/10;
			
		}
		
		System.out.println(rev);

	}

}
