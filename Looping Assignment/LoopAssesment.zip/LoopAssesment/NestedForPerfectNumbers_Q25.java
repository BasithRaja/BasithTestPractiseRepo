//25.
//
//Write a program to print all perfect numbers between 1 and 10000 using:
//
//Nested for
//
//if condition only



package LoopAssesment;

public class NestedForPerfectNumbers_Q25 {

	public static void main(String[] args) {
	
		 for (int num = 1; num <= 10000; num++) {   // outer loop
	            int sum = 0;

	            for (int i = 1; i <= num / 2; i++) {   // inner loop
	                if (num % i == 0) {
	                    sum = sum + i;
	                }
	            }

	            if (sum == num) {
	                System.out.println(num);
	            }
	}

	}
}
