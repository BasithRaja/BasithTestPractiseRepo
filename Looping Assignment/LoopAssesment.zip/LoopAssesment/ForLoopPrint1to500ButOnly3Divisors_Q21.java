package LoopAssesment;

public class ForLoopPrint1to500ButOnly3Divisors_Q21 {

public static void main(String[] args) {
		
		int i;
		int j;
		int count;
		
		for (i = 1; i <=500; i++) {
			
			count = 0;
			
			for (j = 1; j <= i; j++) {
				if (i%j == 0) {
					count++;
				}
			}	
			 if (count == 3) {
					System.out.println(i);
		}
       
		}
	}

}
