//17.
//
//Using do–while, print digits of a number from left to right
//(No strings, no arrays)



package LoopAssesment;

public class DoWhilePrintNumberLeftToRight_Q17 {

    public static void main(String[] args) {

        int num = 12345;
        int temp = num;
        int divisor = 1;

        // Finding the divisor (highest power of 10)
        do {
            divisor = divisor * 10;
            temp = temp / 10;
        } while (temp > 0);

        divisor = divisor / 10;

        // Printing digits from left to right
        do {
            int digit = num / divisor;
            System.out.print(digit + " ");
            num = num % divisor;
            divisor = divisor / 10;
        } while (divisor > 0);
    }
}