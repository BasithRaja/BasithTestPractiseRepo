//16.
//
//Write a program that:
//
//Takes user input until a negative number is entered
//
//Prints sum of all even numbers entered
//➡️ Use do–while




package LoopAssesment;

import java.util.Scanner;

public class DoWhileTakesUserInputandPrintSumEvenNumbers_Q16 {

	public static void main(String[] args) {
	  
		Scanner sc = new Scanner(System.in);
		int userInput;
		int sum = 0;
		
		
		do {
			
			System.out.println("Please Enter a Number:  ");
			userInput = sc.nextInt();
			
			if (userInput >= 0 && userInput%2==0 ) {
			
					sum = userInput+sum;	
				}		
		} while (userInput >= 0 );
           System.out.println("Sum of all Even Numbers is :"+ sum);
           sc.close();
	}

}
