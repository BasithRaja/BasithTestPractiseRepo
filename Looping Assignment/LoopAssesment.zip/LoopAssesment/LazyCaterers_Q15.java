//15.
//
//Using while, print the following sequence:
//
//1 2 4 7 11 16 22 ...
//
//
//(up to N terms)



package LoopAssesment;

public class LazyCaterers_Q15 {

	public static void main(String[] args) {
		
		int N = 20;
		int seriesNumber = 1;
		int difference = 1;
		int i=1;
		

		while (i<=N) {
			System.out.print(seriesNumber+ " ");
			seriesNumber = difference+seriesNumber;
			difference++;
			i++;
		}

	}

}
