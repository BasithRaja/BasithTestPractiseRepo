//3.
//
//Write a program to check if a year is a leap year:


package LoopAssesment;

public class leapyearcheckQ3 {

	public static void main(String[] args) {
		
		
		int year = 5;
		
		if (year % 400 == 0) {   // Checking Special century year like : 1600, 2000, 2400
			 System.out.println(" This is Leap year");
		} else {
			if (year % 100 ==0) {  // Checking Century year like : 1700, 1800, 1900
				System.out.println("This is Not a Leap Year");
			} else {
                if (year % 4 == 0) {    // Checking Normal Leap year like : 2016, 2020, 2024
					System.out.println("This is Leap Year");
				} else {
                    System.out.println("This is Not a Leap Year");
				}
			}
		}

	}

}
